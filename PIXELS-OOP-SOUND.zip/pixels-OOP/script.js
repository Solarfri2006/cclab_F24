function setup() {
    let canvas = createCanvas(640, 480);
    canvas.parent("p5-container");
}

function draw() {
    background(0);
}
