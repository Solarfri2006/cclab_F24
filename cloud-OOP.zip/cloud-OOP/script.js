
function setup() {
    let canvas = createCanvas(400, 400);
    canvas.parent("p5-container");

}

function draw() {
    background(220);
}
